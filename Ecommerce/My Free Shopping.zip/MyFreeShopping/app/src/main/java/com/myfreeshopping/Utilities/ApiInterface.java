package com.myfreeshopping.Utilities;


import com.myfreeshopping.Models.ServerResponseData;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface ApiInterface {


    @GET("register1.php")
    Call<ServerResponseData> performSignUp(@Query("uname") String userName, @Query("mobile") String mobile, @Query("psw") String pwd);

    @Headers("Content-Type: application/json")
    @GET("login1.php")
    Call<ServerResponseData> performSignIn(@Query("mobile") String mobile, @Query("psw") String pwd);

}
